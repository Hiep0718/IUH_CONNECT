package com.iuhconnect.authservice.repository;

import com.iuhconnect.authservice.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    Optional<User> findByUsername(String username);

    java.util.List<User> findByUsernameIn(java.util.List<String> usernames);
}
