package com.iuhconnect.authservice.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class RegisterRequest {

    @NotBlank(message = "Username is required")
    @Size(min = 3, max = 50, message = "Username must be between 3 and 50 characters")
    private String username;

    @NotBlank(message = "Password is required")
    @Size(min = 6, message = "Password must be at least 6 characters")
    private String password;

    private String fullName;

    @jakarta.validation.constraints.Email(message = "Invalid email format")
    private String email;

    private String avatarUrl;

    /** "STUDENT" hoặc "LECTURER". Mặc định STUDENT nếu null */
    private String role;

    /** Bắt buộc nếu role = STUDENT */
    private String studentId;

    /** Bắt buộc nếu role = LECTURER */
    private String lecturerId;

    private String department;
}
